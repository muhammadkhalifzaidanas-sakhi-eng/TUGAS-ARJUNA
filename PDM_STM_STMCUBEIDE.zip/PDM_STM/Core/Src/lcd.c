#include "lcd.h"

static uint8_t display_control = 0;

/* Helper internal: Pulsa Clock pada pin Enable */
static void LCD_EnablePulse(void) {
    HAL_GPIO_WritePin(LCD_PORT, LCD_EN_PIN, GPIO_PIN_SET);
    HAL_Delay(1);
    HAL_GPIO_WritePin(LCD_PORT, LCD_EN_PIN, GPIO_PIN_RESET);
    HAL_Delay(1);
}

/* Helper internal: Mengirim 4-bit (nibble) data ke pin D4-D7 */
static void LCD_SendNibble(uint8_t nibble) {
    HAL_GPIO_WritePin(LCD_PORT, LCD_D4_PIN, (nibble & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_PORT, LCD_D5_PIN, (nibble & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_PORT, LCD_D6_PIN, (nibble & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_PORT, LCD_D7_PIN, (nibble & 0x08) ? GPIO_PIN_SET : GPIO_PIN_RESET);

    LCD_EnablePulse();
}

/* Helper internal: Mengirim 1 byte (2x 4-bit) */
static void LCD_SendByte(uint8_t byte) {
    LCD_SendNibble(byte >> 4);   // Kirim 4 bit tinggi
    LCD_SendNibble(byte & 0x0F); // Kirim 4 bit rendah
}

/* Helper internal: Mengirim perintah */
static void LCD_Command(uint8_t cmd) {
    HAL_GPIO_WritePin(LCD_PORT, LCD_RS_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(LCD_PORT, LCD_RW_PIN, GPIO_PIN_RESET);

    LCD_SendByte(cmd);

    if (cmd == LCD_CLEARDISPLAY || cmd == LCD_RETURNHOME) {
        HAL_Delay(2);
    }
}

/* ===== Fungsi Utama Implementasi lcd.h ===== */

void initLCD(void) {
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_AFIO_CLK_ENABLE();

    /* Matikan JTAG agar PB3 & PB4 berfungsi sebagai GPIO biasa */
    __HAL_AFIO_REMAP_SWJ_NOJTAG();

    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = LCD_EN_PIN | LCD_RW_PIN | LCD_RS_PIN |
                          LCD_D4_PIN | LCD_D5_PIN | LCD_D6_PIN | LCD_D7_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(LCD_PORT, &GPIO_InitStruct);

    HAL_GPIO_WritePin(LCD_PORT, GPIO_InitStruct.Pin, GPIO_PIN_RESET);

    HAL_Delay(50);

    /* Inisialisasi Mode 4-Bit HD44780 */
    LCD_SendNibble(0x03);
    HAL_Delay(5);
    LCD_SendNibble(0x03);
    HAL_Delay(1);
    LCD_SendNibble(0x03);
    HAL_Delay(1);
    LCD_SendNibble(0x02); // Pindah ke Mode 4-bit

    /* Konfigurasi Tampilan */
    LCD_Command(LCD_FUNCTIONSET | LCD_4BITMODE | LCD_2LINE | LCD_5x8DOTS);

    display_control = LCD_DISPLAYON | LCD_CURSOROFF | LCD_BLINKOFF;
    LCD_Command(LCD_DISPLAYCONTROL | display_control);

    clearLCD();
    LCD_Command(LCD_ENTRYMODESET | LCD_ENTRYLEFT | LCD_ENTRYSHIFTDECREMENT);
}

void clearLCD(void) {
    LCD_Command(LCD_CLEARDISPLAY);
    HAL_Delay(2);
}

void putLCD(char c) {
    HAL_GPIO_WritePin(LCD_PORT, LCD_RS_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(LCD_PORT, LCD_RW_PIN, GPIO_PIN_RESET);

    LCD_SendByte((uint8_t)c);
}

void writeLCD(char *str) {
    while (*str) {
        putLCD(*str++);
    }
}

void setCursor(char x, char y) {
    uint8_t address = (y == 0) ? (0x00 + x) : (0x40 + x);
    LCD_Command(LCD_SETDDRAMADDR | address);
}

void setDisplay(lcdDispSetting_t dispSetting) {
    display_control |= dispSetting;
    LCD_Command(LCD_DISPLAYCONTROL | display_control);
}

void clearDisp(void) {
    display_control = LCD_DISPLAYOFF;
    LCD_Command(LCD_DISPLAYCONTROL | display_control);
}

void cursorOn(void) {
    display_control |= LCD_CURSORON;
    LCD_Command(LCD_DISPLAYCONTROL | display_control);
}

void blinkOn(void) {
    display_control |= LCD_BLINKON;
    LCD_Command(LCD_DISPLAYCONTROL | display_control);
}
