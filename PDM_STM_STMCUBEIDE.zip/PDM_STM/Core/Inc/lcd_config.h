#ifndef INC_LCD_CONFIG_H_
#define INC_LCD_CONFIG_H_

#ifndef STM32F1
#define STM32F1
#endif

/* Pin Control Sesuai CubeMX & Proteus */
#define LCD_PORT        GPIOB
#define LCD_EN_PIN      GPIO_PIN_0   // PB0 = E
#define LCD_RW_PIN      GPIO_PIN_1   // PB1 = RW
#define LCD_RS_PIN      GPIO_PIN_2   // PB2 = RS

/* Pin Data Sesuai CubeMX (Mode 4-Bit: PB4-PB7) */
#define LCD_D4_PIN      GPIO_PIN_4
#define LCD_D5_PIN      GPIO_PIN_5
#define LCD_D6_PIN      GPIO_PIN_6
#define LCD_D7_PIN      GPIO_PIN_7

#endif /* INC_LCD_CONFIG_H_ */
